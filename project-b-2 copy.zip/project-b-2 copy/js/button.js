function startGameButton(){
    document.getElementById("mainFlexContainer").style.display = "none";
    // console.log("hello!"); 
    window.location.href = "./first.html"    
  }

  function backButton(){
    // document.getElementById("mainFlexContainer").style.display = "flex";
    window.location.href = "./"
  }