let currentSceneIndex = 1;
let catRoomImg, citystreetImg, receptionistsImg; 
let receptionImg, catImg;
let suitcase1,suitcase2,suitcase3;
let suitcases=[];
let ball1, ball2, ball3;
let notDraggedBalls =[];
let notDraggedSuitcases = [];
let balls = [];
let fillBox = 0;
let car1x = 0;
let fillSuitcase = 0;
let ifDragging = false;

function preload(){
  catRoomImg = loadImage("./assets/cat-room.png");
  citystreetImg = loadImage("./assets/citystreet.png");
  catImg = loadImage("./assets/cat.png")
  suitcase1 = loadImage("./assets/suitcase1.png"); 
  suitcase2= loadImage("./assets/suitcase2.png");
  suitcase3= loadImage("./assets/suitcase3.png");
  ball1 = loadImage("./assets/ball-1.png")
  ball2 = loadImage("./assets/ball-2.png")
  ball3 = loadImage("./assets/ball-3.png")
  
  receptionistsImg = loadImage("./assets/recepcionist.jpeg")
  receptionImg = loadImage("./assets/reception.png")

} 

function setup() {
  let canvas =  createCanvas(windowWidth, windowHeight);
  textFont("Georgia");
  canvas.parent("canvasContainer");
  imageMode(CENTER);
  balls.push(new Ball(random(width),random(height) / 2, ball1));
  balls.push(new Ball(width / 2,height / 2, ball2));
  balls.push(new Ball(width / 2 - 200,height / 2 + 100, ball3));
  notDraggedBalls = balls;
  suitcases.push(new Ball(width / 2 - 180,height / 2 + 100,suitcase1));
  suitcases.push(new Ball(width / 2 ,height / 2 + 100,suitcase2));
  suitcases.push(new Ball(width / 2 + 180,height / 2 + 100 ,suitcase2));
  notDraggedSuitcases = suitcases;
}
function draw() {
  background(220);

  push();
 
  if(currentSceneIndex == 1){
    image(catRoomImg, width / 2, height / 2, width, height);
    for(let i = 0; i < balls.length; i++){
      // if(!ifDragging){
      //   balls[i].update();
      // }
      // else{
      //   if(balls[i].beDragged){
         
      //     console.log("hiiiii")
      //   }
      // }
      balls[i].update();
      balls[i].display();
    }
    
    rectMode(CENTER);
      push();
          noStroke();
          fill(24, 49, 161);
         rect( 1300, 680, 150, 200);
         fill(30, 57, 179);
         rect( 1350, 650, 100, 70);
         fill(0);
         circle( 1225, 780, 20);
         circle( 1375, 780, 20);

      pop();
    textSize(24);
    textAlign(CENTER);
    text("The Cat's Cozy Quarters", width / 2, 30);
    fill("green");
  

  }else if(currentSceneIndex == 2){
    image(citystreetImg, width / 2, height / 2, width, height);
    drawCar(car1x, height - 120, 5);
    car1x += 5;
  
   if(car1x > width + 60){
    car1x = -100;
  }
  
    textSize(24);
    textAlign(CENTER);
    text("The Bustling City Streets", width / 2, 30);
  
  }
  else if(currentSceneIndex == 3){
 
    image(receptionImg, width / 2, height / 2, width, height);
    image(receptionistsImg, width/2, height/2 + 10 , width /2 - 100 , height / 2);

    textSize(24);
    
    textAlign(CENTER);
    text("The Mysterious Hotel", width / 2, 30);

    for(let i = 0; i < suitcases.length; i++){
    suitcases[i].update();
    suitcases[i].display();
    }
    
    fill('#931420');
    rect(0, height * 0.75, width, height * 0.25);
  
    // Stairs drawing
    push();
    fill('#964241');
    strokeWeight(4);
    for (let i = 0; i < 5; i++) {
        rect(width * 0.25 - i * 20, height * 0.75 - i * 20, width * 0.5 + i * 40, 20);
    }
    pop();
    fill('#77182a');
 
  
    // Speech bubble for interaction prompt
    push();
    fill('#ffbda9');
    rect(500, 150, 200, 90, 50);
    fill('#853b40');
    textSize(13);
    textAlign(CENTER, CENTER);
    text("Welcome! Please give me ", 600, 170);
    text("your luggages to check-in!", 600, 190);
    text("(Drag the luggages", 600, 210);
    text(" to check-in!)", 600, 230);
    pop();

  
  }
  pop();
}

function drawCar(x, y, speed) {
  push();
  translate(x, y);

  // light
  fill("blue");
  ellipse(-10, -40, 10, 20);

  // body
  fill(0);
  rect(-20, -40, 40, 40);
  rect(-60, 0, 120, 40);

  // window
  fill(198, 238, 255);
  rect(-17, -37, 34, 37, 5);

  // driver
  textSize(30);
  text("👮‍♀️", -15, -5);

  // decoration
  fill("red");
  rect(-60, 20, 120, 5);
  fill("blue");
  rect(-60, 25, 120, 5);

  // wheels
  fill(0);
  // rotate(radians(180));
  // circle(-25, 40, 30);
  drawSpinningWheel(-25, 40, speed);
  // circle(25, 40, 30);
  drawSpinningWheel(25, 40, speed);

  fill("red");
  circle(0, 0, 5);

  pop();
}

function drawSpinningWheel(x, y, speed) {
  push();
  translate(x, y);
  rotate(radians(frameCount * speed));
  fill(0);
  circle(0, 0, 30);
  fill("grey");
  rect(-10, -10, 20, 20);

  fill("green");
  circle(0, 0, 5);
  pop();
}
// function startGameButton(){
//   document.getElementById("mainFlexContainer").style.display = "none";
//   // console.log("hello!"); 
//   currentSceneIndex = 1;
// }
function mousePressed() {
  for (let i = 0; i < suitcases.length; i++) {
    suitcases[i].clicked();
  }
}
function mouseReleased() {
  for( let i = 0; i < notDraggedBalls.length; i++){
    if( currentSceneIndex == 1 && notDraggedBalls[i].x > 1200 && notDraggedBalls[i].x < 1400 && notDraggedBalls[i].y > 610 && notDraggedBalls[i].y < 755){
      fillBox++;
      notDraggedBalls.splice(i, 1);
      i--;
    } 
  }
  if(currentSceneIndex == 1 && notDraggedBalls.length == 0){
    currentSceneIndex = 2;

  }

  for (let i = 0; i < notDraggedSuitcases.length; i++){
    for (let i = 0; i < suitcases.length; i++) {
      suitcases[i].notClicked();
    }
      checkSuitcasePlacement();
  }
  
  function checkSuitcasePlacement() {
    // check if suitcases are placed in a specific area
    for (let i = 0; i < suitcases.length; i++) {
      if (suitcases[i].x > 500 && suitcases[i].x < 1100 && suitcases[i].y > 300 && suitcases[i].y < 500) {
        fillSuitcase++;
        // Remove from notDraggedSuitcases array if needed
      }
    }
    // Check to show cat image if condition met
    // if(fillSuitcase >= 3){
    //   image(catImg, 1300, 100, 100, 100); // Adjust coordinates as needed
    // }
    if (fillSuitcase == suitcases.length) {  // If all suitcases are placed correctly
      currentSceneIndex = 3; 
      image(catImg, 800, 100, 100, 100); // Draw the cat
    }
  }
}
function keyPressed(){
  if(currentSceneIndex == 1){
    currentSceneIndex = 2;
    } 
    else{
      currentSceneIndex ++;
    }
  
}
class Ball{
  constructor(x, y, img){
    this.x = x;
    this.y = y;
    this.beDragged = false;
    this.img = img;
  }
  update(){
    let distanceFromCenter = dist(this.x, this.y, mouseX, mouseY);
    if(distanceFromCenter < 100){
      if(mouseIsPressed == true){
      // this.beDragged = true;
      // ifDragging = true;
        this.x = mouseX;
        this.y = mouseY;
      } 
    //   else {
    //     ifDragging = false;
    //     this.beDragged = false;
    //   }
      
    // } else{
    //   ifDragging = false;
    //   this.beDragged = false;
    // }
  }
}
  display(){
    push();
    translate(this.x, this.y);
    image(this.img, 0, 0, 100, 100);
    pop();
  }
  clicked() {
    let d = dist(mouseX, mouseY, this.x, this.y);
    if (d < 50) {  // Assuming the suitcase is draggable if the mouse is within 50 pixels
      this.beDragged = true;
    }
  }

  notClicked() {
    this.beDragged = false;
  }
}

