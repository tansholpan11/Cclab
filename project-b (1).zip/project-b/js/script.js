let scenes = [];
let currentSceneIndex = 0;
let catImg, anImg;
let suitcase1,suitcase2,suitcase3;
let suitcases=[];

function preload(){
  catImg = loadImage("../assets/cat.png");
  // anImg = loadImage("../assets/an.png");
  suitcase1 = loadImage("../assets/suitcase1.png");
  // suitcase2= loadImage("../assets/suitcase2.png");
  // suitcase3= loadImage("../assets/suitcase3.png");
}

function setup() {
  let canvas =  createCanvas(windowWidth, windowHeight);
  textFont("Georgia");
  canvas.parent("canvasContainer");
  imageMode(CENTER);
suitcases.push(new Suitcase(width / 2,height / 2,suitcase1));

}

function draw() {
  background(220);

  push();
  
  if(currentSceneIndex == 0){
    image(catImg, width / 2, height / 2, width, height);
    suitcases[0].update();
  suitcases[0].display();
  }else if(currentSceneIndex == 1){
    // write scene 2 objects
  }else if(currentSceneIndex == 2){
    image(anImg, width / 2, height / 2, width, height);
  }
  pop();

  
  
  // scenes[currentSceneIndex].update(); 
  // scenes[currentSceneIndex].display(); 
}
function startGameButton(){
  document.getElementById("mainFlexContainer").style.display = "none";
  console.log("hello!");
  
}
function mousePressed() {
  currentSceneIndex = (currentSceneIndex + 1) % scenes.length;
  scenes[currentSceneIndex].mousePressed();
}

class Suitcase {
  constructor(x, y, img) {
    this.x = x;
    this.y = y;
    this.img = img;
  }
  update(){
    let distanceFromCenter = dist(this.x, this.y, mouseX, mouseY)
    if(distanceFromCenter < 100){
      this.x = mouseX;
      this.y = mouseY;
    }
  }
  display() {
    push();
    translate(this.x, this.y);
    image(this.img, 0, 0, 100, 100); // imageSrc, x, y, width, height
    pop();
    // textSize(24);
    // textAlign(CENTER);
    // text("Welcome to Princess Catnapping", width / 2, height / 2);
  }
}

class CatRoomScene {
  display() {
    textSize(24);
    textAlign(CENTER);
    text("The Cat's Cozy Quarters", width / 2, height / 2);
    fill("green");
    rect(100, 150, 200, 100);  // Interactive area
  }

  mousePressed() {
    
    if (mouseX >= 300 && mouseX <= 500 && mouseY >= 250 && mouseY <= 350) {
      this.nextScene();
    }
  }

  nextScene() {
    currentSceneIndex = 2; // Move to the City Scene
  }
}

class CityScene {
  display() {
    textSize(24);
    textAlign(CENTER);
    text("The Bustling City Streets", width / 2, height / 2);
  }
}

class HotelScene {
  display() {
    textSize(24);
    textAlign(CENTER);
    text("The Mysterious Hotel", width / 2, height / 2);
    fill("red");
    rect(100, 150, 200, 100);  // Interactive area
  }

  mousePressed() {
    // Check if the click is within the interactive area
    if (mouseX >= 300 && mouseX <= 500 && mouseY >= 250 && mouseY <= 350) {
      this.nextScene();
    }
  }

  nextScene() {
    currentSceneIndex = 0; // go back to the Introduction
  }
}
